import { products, cartItems, inquiries, type Product, type InsertProduct, type CartItem, type InsertCartItem, type Inquiry, type InsertInquiry } from "@shared/schema";

export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductsByCategory(category: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Cart
  getCartItems(): Promise<CartItem[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  removeFromCart(id: number): Promise<void>;
  clearCart(): Promise<void>;
  
  // Inquiries
  createInquiry(inquiry: InsertInquiry): Promise<Inquiry>;
  getInquiries(): Promise<Inquiry[]>;
}

export class MemStorage implements IStorage {
  private products: Map<number, Product>;
  private cartItems: Map<number, CartItem>;
  private inquiries: Map<number, Inquiry>;
  private currentProductId: number;
  private currentCartId: number;
  private currentInquiryId: number;

  constructor() {
    this.products = new Map();
    this.cartItems = new Map();
    this.inquiries = new Map();
    this.currentProductId = 1;
    this.currentCartId = 1;
    this.currentInquiryId = 1;
    
    // Initialize with sample products
    this.initializeProducts();
  }

  private initializeProducts() {
    const sampleProducts: InsertProduct[] = [
      {
        name: "Classic Diamond Solitaire",
        description: "1.5ct round brilliant diamond in platinum setting. A timeless symbol of eternal love.",
        price: "8500.00",
        category: "rings",
        image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
        images: [
          "https://images.unsplash.com/photo-1605100804763-247f67b3557e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
          "https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600"
        ],
        metal: "Platinum",
        stone: "Diamond",
        carat: "1.5ct",
        setting: "Prong Setting",
        inStock: true
      },
      {
        name: "Akoya Pearl Necklace",
        description: "18\" strand of lustrous Akoya pearls with 14k gold clasp. Elegant and sophisticated.",
        price: "2750.00",
        category: "necklaces",
        image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
        images: [
          "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
          "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600"
        ],
        metal: "14k Gold",
        stone: "Akoya Pearl",
        carat: "N/A",
        setting: "Strand",
        inStock: true
      },
      {
        name: "Diamond Stud Earrings",
        description: "1ct total weight, brilliant cut diamonds in 18k white gold. Perfect for everyday elegance.",
        price: "4200.00",
        category: "earrings",
        image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
        images: [
          "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
          "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600"
        ],
        metal: "18k White Gold",
        stone: "Diamond",
        carat: "1ct total",
        setting: "Stud",
        inStock: true
      },
      {
        name: "Diamond Tennis Bracelet",
        description: "3ct total weight diamonds in 18k yellow gold setting. A statement of luxury.",
        price: "6800.00",
        category: "bracelets",
        image: "https://images.unsplash.com/photo-1611652022419-a9419f74343d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
        images: [
          "https://images.unsplash.com/photo-1611652022419-a9419f74343d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
          "https://images.unsplash.com/photo-1543294001-f7cd5d7fb516?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600"
        ],
        metal: "18k Yellow Gold",
        stone: "Diamond",
        carat: "3ct total",
        setting: "Tennis",
        inStock: true
      },
      {
        name: "Ceylon Sapphire Ring",
        description: "2ct Ceylon sapphire with diamond halo in platinum. A rare and exquisite piece.",
        price: "7500.00",
        category: "rings",
        image: "https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
        images: [
          "https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
          "https://images.unsplash.com/photo-1605100804763-247f67b3557e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600"
        ],
        metal: "Platinum",
        stone: "Ceylon Sapphire",
        carat: "2ct",
        setting: "Halo",
        inStock: true
      },
      {
        name: "Rose Gold Heart Pendant",
        description: "Delicate heart pendant in 14k rose gold with diamond accent. Perfect for layering.",
        price: "1250.00",
        category: "necklaces",
        image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
        images: [
          "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
          "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600"
        ],
        metal: "14k Rose Gold",
        stone: "Diamond",
        carat: "0.1ct",
        setting: "Pendant",
        inStock: true
      }
    ];

    sampleProducts.forEach(product => {
      this.createProduct(product);
    });
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      product => product.category === category
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = { ...insertProduct, id };
    this.products.set(id, product);
    return product;
  }

  async getCartItems(): Promise<CartItem[]> {
    return Array.from(this.cartItems.values());
  }

  async addToCart(insertCartItem: InsertCartItem): Promise<CartItem> {
    const id = this.currentCartId++;
    const cartItem: CartItem = { ...insertCartItem, id };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }

  async removeFromCart(id: number): Promise<void> {
    this.cartItems.delete(id);
  }

  async clearCart(): Promise<void> {
    this.cartItems.clear();
  }

  async createInquiry(insertInquiry: InsertInquiry): Promise<Inquiry> {
    const id = this.currentInquiryId++;
    const inquiry: Inquiry = { 
      ...insertInquiry, 
      id, 
      createdAt: new Date().toISOString() 
    };
    this.inquiries.set(id, inquiry);
    return inquiry;
  }

  async getInquiries(): Promise<Inquiry[]> {
    return Array.from(this.inquiries.values());
  }
}

export const storage = new MemStorage();
