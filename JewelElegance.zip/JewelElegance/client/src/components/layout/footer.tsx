import { Link } from "wouter";
import { Facebook, Instagram, Twitter } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-white border-t py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="mb-4">
              <h3 className="text-2xl font-playfair font-bold text-champagne">LUXE</h3>
              <p className="text-xs text-gray-500 -mt-1">JEWELRY</p>
            </div>
            <p className="text-gray-600 mb-4">
              Crafting timeless elegance since 1985. Each piece tells a story of luxury, craftsmanship, and enduring beauty.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-champagne transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-champagne transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-champagne transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Collections */}
          <div>
            <h4 className="font-semibold text-charcoal mb-4">Collections</h4>
            <ul className="space-y-2 text-gray-600">
              <li>
                <Link href="/category/rings">
                  <a className="hover:text-champagne transition-colors">Engagement Rings</a>
                </Link>
              </li>
              <li>
                <Link href="/category/rings">
                  <a className="hover:text-champagne transition-colors">Wedding Bands</a>
                </Link>
              </li>
              <li>
                <Link href="/category/necklaces">
                  <a className="hover:text-champagne transition-colors">Fine Necklaces</a>
                </Link>
              </li>
              <li>
                <Link href="/category/earrings">
                  <a className="hover:text-champagne transition-colors">Diamond Earrings</a>
                </Link>
              </li>
              <li>
                <Link href="/category/bracelets">
                  <a className="hover:text-champagne transition-colors">Luxury Bracelets</a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold text-charcoal mb-4">Services</h4>
            <ul className="space-y-2 text-gray-600">
              <li><a href="#contact" className="hover:text-champagne transition-colors">Custom Design</a></li>
              <li><a href="#" className="hover:text-champagne transition-colors">Ring Sizing</a></li>
              <li><a href="#" className="hover:text-champagne transition-colors">Jewelry Repair</a></li>
              <li><a href="#" className="hover:text-champagne transition-colors">Appraisals</a></li>
              <li><a href="#" className="hover:text-champagne transition-colors">Cleaning & Maintenance</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold text-charcoal mb-4">Customer Care</h4>
            <ul className="space-y-2 text-gray-600">
              <li><a href="#" className="hover:text-champagne transition-colors">Size Guide</a></li>
              <li><a href="#" className="hover:text-champagne transition-colors">Care Instructions</a></li>
              <li><a href="#" className="hover:text-champagne transition-colors">Returns & Exchanges</a></li>
              <li><a href="#" className="hover:text-champagne transition-colors">Shipping Info</a></li>
              <li><a href="#contact" className="hover:text-champagne transition-colors">Contact Us</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-600 text-sm">© 2024 Luxe Jewelry. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0 text-sm text-gray-600">
            <a href="#" className="hover:text-champagne transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-champagne transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-champagne transition-colors">Warranty</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
