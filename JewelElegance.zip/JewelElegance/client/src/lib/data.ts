export const categories = [
  {
    id: "rings",
    name: "Rings",
    description: "Engagement, wedding, and statement rings",
    image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
  },
  {
    id: "necklaces",
    name: "Necklaces",
    description: "Pendants, chains, and statement pieces",
    image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
  },
  {
    id: "earrings",
    name: "Earrings",
    description: "Studs, hoops, and drop earrings",
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
  },
  {
    id: "bracelets",
    name: "Bracelets",
    description: "Tennis, charm, and cuff bracelets",
    image: "https://images.unsplash.com/photo-1611652022419-a9419f74343d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800"
  }
];

export const jewelryTypes = [
  "Engagement Ring",
  "Wedding Ring", 
  "Necklace",
  "Earrings",
  "Bracelet",
  "Other"
];

export const budgetRanges = [
  "$1,000 - $2,500",
  "$2,500 - $5,000", 
  "$5,000 - $10,000",
  "$10,000+"
];

export const sizes = ["5", "6", "7", "8", "9"];
