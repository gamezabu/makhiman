import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import ProductCard from "@/components/products/product-card";
import ContactForm from "@/components/contact/contact-form";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import type { Product } from "@shared/schema";

export default function Home() {
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const featuredProducts = products?.slice(0, 6) || [];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-black/20 z-10"></div>
        <img 
          src="https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
          alt="Luxury jewelry collection display" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        
        <div className="relative z-20 text-center text-white px-4">
          <h1 className="text-5xl md:text-7xl font-playfair font-bold mb-6">
            Timeless Elegance
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto font-light">
            Discover our exquisite collection of handcrafted fine jewelry, where each piece tells a story of luxury and sophistication.
          </p>
          <Link href="#featured-products">
            <Button size="lg" className="bg-champagne hover:bg-rose-gold text-white px-8 py-4 text-lg font-medium transition-all duration-300 transform hover:scale-105">
              EXPLORE COLLECTION
            </Button>
          </Link>
        </div>
      </section>

      {/* Category Showcase */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-playfair font-bold text-charcoal mb-4">Our Collections</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">Each category represents centuries of craftsmanship and modern design excellence</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                name: "Rings",
                description: "Engagement, wedding, and statement rings",
                image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
                category: "rings"
              },
              {
                name: "Necklaces", 
                description: "Pendants, chains, and statement pieces",
                image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
                category: "necklaces"
              },
              {
                name: "Earrings",
                description: "Studs, hoops, and drop earrings", 
                image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
                category: "earrings"
              },
              {
                name: "Bracelets",
                description: "Tennis, charm, and cuff bracelets",
                image: "https://images.unsplash.com/photo-1611652022419-a9419f74343d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800",
                category: "bracelets"
              }
            ].map((category) => (
              <Link key={category.category} href={`/category/${category.category}`}>
                <div className="group cursor-pointer">
                  <div className="relative overflow-hidden bg-light-grey rounded-lg mb-4 aspect-square">
                    <img 
                      src={category.image} 
                      alt={`${category.name} collection`} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors duration-300"></div>
                  </div>
                  <h3 className="text-2xl font-playfair font-semibold text-charcoal mb-2">{category.name}</h3>
                  <p className="text-gray-600">{category.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section id="featured-products" className="py-20 bg-off-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-playfair font-bold text-charcoal mb-4">Featured Collection</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">Handpicked pieces that exemplify our commitment to excellence</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {isLoading
              ? Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-lg overflow-hidden">
                    <Skeleton className="aspect-square w-full" />
                    <div className="p-6 space-y-4">
                      <Skeleton className="h-6 w-3/4" />
                      <Skeleton className="h-4 w-full" />
                      <div className="flex justify-between items-center">
                        <Skeleton className="h-8 w-20" />
                        <Skeleton className="h-10 w-24" />
                      </div>
                    </div>
                  </div>
                ))
              : featuredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
          </div>

          <div className="text-center">
            <Link href="/category/rings">
              <Button size="lg" variant="outline" className="border-charcoal text-charcoal hover:bg-charcoal hover:text-white">
                VIEW ALL PRODUCTS
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <ContactForm />
    </div>
  );
}
